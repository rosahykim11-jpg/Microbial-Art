import { useState, useEffect } from "react";
import { supabase } from "../supabaseClient";

export default function Articles({ session }) {
  const [articles, setArticles] = useState([]);
  const [view, setView] = useState("list"); // "list" | "read" | "write" | "edit"
  const [selected, setSelected] = useState(null);
  const [form, setForm] = useState({ title: "", body: "" });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState("all"); // "all" | "mine"

  const userId = session.user.id;
  const username = session.user.user_metadata?.username || session.user.email?.split("@")[0];

  const fetchArticles = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("articles")
      .select("*")
      .order("created_at", { ascending: false });
    if (!error) setArticles(data || []);
    setLoading(false);
  };

  useEffect(() => { fetchArticles(); }, []);

  const handlePublish = async () => {
    if (!form.title.trim() || !form.body.trim()) return setError("Title and body are required.");
    setSaving(true);
    setError("");
    if (view === "edit" && selected) {
      const { error } = await supabase
        .from("articles")
        .update({ title: form.title, body: form.body, updated_at: new Date().toISOString() })
        .eq("id", selected.id);
      if (error) return setError(error.message);
    } else {
      const { error } = await supabase
        .from("articles")
        .insert({ title: form.title, body: form.body, user_id: userId, author: username });
      if (error) return setError(error.message);
    }
    setSaving(false);
    setForm({ title: "", body: "" });
    setView("list");
    fetchArticles();
  };

  const handleDelete = async (id) => {
    if (!confirm("Delete this article?")) return;
    await supabase.from("articles").delete().eq("id", id);
    setView("list");
    fetchArticles();
  };

  const openEdit = (article) => {
    setSelected(article);
    setForm({ title: article.title, body: article.body });
    setView("edit");
  };

  const openRead = (article) => {
    setSelected(article);
    setView("read");
  };

  const formatDate = (iso) =>
    new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });

  const filtered = filter === "mine" ? articles.filter((a) => a.user_id === userId) : articles;

  // ── LIST VIEW ──
  if (view === "list") return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold text-white" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>Articles</h2>
          <p className="text-zinc-500 text-sm mt-0.5">{articles.length} published</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex bg-zinc-800/60 rounded-xl p-1 gap-1">
            <button
              onClick={() => setFilter("all")}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${filter === "all" ? "bg-zinc-700 text-white" : "text-zinc-400 hover:text-zinc-200"}`}
            >
              All
            </button>
            <button
              onClick={() => setFilter("mine")}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${filter === "mine" ? "bg-zinc-700 text-white" : "text-zinc-400 hover:text-zinc-200"}`}
            >
              Mine
            </button>
          </div>
          <button
            onClick={() => { setForm({ title: "", body: "" }); setView("write"); setError(""); }}
            className="flex items-center gap-1.5 px-4 py-2 bg-violet-600 hover:bg-violet-500 text-white text-sm font-medium rounded-xl transition-colors"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Write
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-16">
          <div className="w-6 h-6 border-2 border-violet-500 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20 text-zinc-600">
          <svg className="w-12 h-12 mx-auto mb-3 opacity-30" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          <p className="text-sm">No articles yet. Be the first to write one!</p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((article) => (
            <div
              key={article.id}
              onClick={() => openRead(article)}
              className="group bg-zinc-900 border border-zinc-800 hover:border-zinc-600 rounded-2xl p-6 cursor-pointer transition-all duration-200 hover:shadow-xl hover:shadow-black/30 hover:-translate-y-0.5"
            >
              <h3 className="font-semibold text-white text-lg mb-2 line-clamp-2 group-hover:text-violet-300 transition-colors" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                {article.title}
              </h3>
              <p className="text-zinc-500 text-sm line-clamp-3 mb-4 leading-relaxed">{article.body}</p>
              <div className="flex items-center justify-between text-xs text-zinc-600">
                <span className="flex items-center gap-1">
                  <div className="w-5 h-5 rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center text-white font-bold text-[10px]">
                    {article.author?.charAt(0).toUpperCase()}
                  </div>
                  {article.author}
                </span>
                <span>{formatDate(article.created_at)}</span>
              </div>
              {article.user_id === userId && (
                <div className="mt-3 pt-3 border-t border-zinc-800 flex gap-2">
                  <button
                    onClick={(e) => { e.stopPropagation(); openEdit(article); }}
                    className="text-xs text-zinc-400 hover:text-violet-400 transition-colors px-2 py-1 rounded-lg hover:bg-violet-500/10"
                  >
                    Edit
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); handleDelete(article.id); }}
                    className="text-xs text-zinc-400 hover:text-red-400 transition-colors px-2 py-1 rounded-lg hover:bg-red-500/10"
                  >
                    Delete
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );

  // ── READ VIEW ──
  if (view === "read" && selected) return (
    <div className="max-w-2xl mx-auto">
      <button onClick={() => setView("list")} className="flex items-center gap-1.5 text-zinc-400 hover:text-white text-sm mb-8 transition-colors">
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
        Back to articles
      </button>
      <article className="space-y-6">
        <div>
          <h1 className="text-4xl font-bold text-white leading-tight mb-4" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
            {selected.title}
          </h1>
          <div className="flex items-center gap-3 text-sm text-zinc-500">
            <div className="flex items-center gap-1.5">
              <div className="w-6 h-6 rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center text-white font-bold text-xs">
                {selected.author?.charAt(0).toUpperCase()}
              </div>
              <span>{selected.author}</span>
            </div>
            <span>·</span>
            <span>{formatDate(selected.created_at)}</span>
            {selected.updated_at && selected.updated_at !== selected.created_at && (
              <><span>·</span><span className="text-zinc-600">edited {formatDate(selected.updated_at)}</span></>
            )}
          </div>
        </div>
        <div className="h-px bg-zinc-800" />
        <p className="text-zinc-300 leading-8 whitespace-pre-wrap text-[1.05rem]">{selected.body}</p>
        {selected.user_id === userId && (
          <div className="flex gap-3 pt-4 border-t border-zinc-800">
            <button
              onClick={() => openEdit(selected)}
              className="px-4 py-2 text-sm bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl border border-zinc-700 transition-colors"
            >
              Edit article
            </button>
            <button
              onClick={() => handleDelete(selected.id)}
              className="px-4 py-2 text-sm bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-xl border border-red-500/20 transition-colors"
            >
              Delete
            </button>
          </div>
        )}
      </article>
    </div>
  );

  // ── WRITE / EDIT VIEW ──
  return (
    <div className="max-w-2xl mx-auto">
      <button
        onClick={() => { setView("list"); setError(""); }}
        className="flex items-center gap-1.5 text-zinc-400 hover:text-white text-sm mb-8 transition-colors"
      >
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
        Cancel
      </button>

      <h2 className="text-2xl font-bold text-white mb-6" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
        {view === "edit" ? "Edit Article" : "New Article"}
      </h2>

      <div className="space-y-4">
        <div>
          <input
            type="text"
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            placeholder="Article title…"
            className="w-full bg-zinc-900 border border-zinc-800 focus:border-violet-500 focus:ring-1 focus:ring-violet-500/20 rounded-xl px-4 py-3 text-white placeholder-zinc-600 text-lg font-semibold outline-none transition-all"
            style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
          />
        </div>
        <div>
          <textarea
            value={form.body}
            onChange={(e) => setForm({ ...form, body: e.target.value })}
            placeholder="Write your article here…"
            rows={16}
            className="w-full bg-zinc-900 border border-zinc-800 focus:border-violet-500 focus:ring-1 focus:ring-violet-500/20 rounded-xl px-4 py-3 text-zinc-200 placeholder-zinc-600 text-sm leading-7 outline-none transition-all resize-none"
          />
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-3 text-red-400 text-sm">
            {error}
          </div>
        )}

        <div className="flex gap-3">
          <button
            onClick={handlePublish}
            disabled={saving}
            className="flex items-center gap-2 px-6 py-2.5 bg-violet-600 hover:bg-violet-500 text-white font-medium rounded-xl transition-colors disabled:opacity-50"
          >
            {saving ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            )}
            {view === "edit" ? "Save Changes" : "Publish"}
          </button>
          <button
            onClick={() => { setView("list"); setError(""); }}
            className="px-6 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl border border-zinc-700 transition-colors"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
